# StudyBridge

A simple prototype based on your handwritten app idea.

Features:
- Student/Teacher login
- Subject dashboard
- Live-class screen
- Doubt submission
- Class discussion/chat
- Save-notes demo

Important:
The live video area is only a frontend prototype. For a real school deployment, connect it to an approved video/live-stream backend, add authentication, teacher controls, moderation, and school privacy/consent requirements.
